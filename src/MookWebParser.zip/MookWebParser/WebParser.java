package MookWebParser;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
//import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebParser {
	
	public PrintWriter log;
	
	public WebParser() throws FileNotFoundException {
		
		log = new PrintWriter("thairath_news.doc");
	}
	
	public static void main(String[] args) throws IOException {
		
		String webname = "http://www.thairath.co.th/lifestyle/tech";
//		String webname = "https://jsoup.org/";
		
		WebParser w = new WebParser();
		ArrayList<WebContent> webInfo = w.getHeadLine(webname);
		
		w.printLog(webInfo);
		
		(w.log).flush();
		(w.log).close();
		
		System.out.println("Done.");
				
				
	}
	
	public ArrayList<WebContent> getHeadLine(String url) throws IOException {
		
		Document doc = Jsoup.connect(url).get();
		
		ArrayList<WebContent> infoList = new ArrayList<WebContent>();
		
		Elements headlines = doc.select("div.lastestNews div.cardRow div.card-block h4");
//		Elements contlines = doc.select("div.lastestNews div.cardRow div.card-block p");
		Elements headURLs = doc.select("div.lastestNews div.cardRow div.card-block h4 a");
//		Elements contURLs = doc.select("div.lastestNews div.cardRow div.card-block p a");
		
		for(int i = 0; i < headlines.size(); i++) {
			
			String absHref = headURLs.get(i).attr("abs:href");
			
			WebContent news = new WebContent();
			news.setHeadline(headlines.get(i).text());
			news.setURL(absHref);
			goToWeb(absHref,news);
			infoList.add(news);
			
		}

		return infoList;
	}
	
	public WebContent goToWeb(String url, WebContent news) throws IOException {
		
		Document doc = Jsoup.connect(url).get();
		
		Elements date = doc.select("section#headerContent time");
		
//		Date and Time
			news.setDate(date.text());
		
//		Content
		Elements content = doc.select("div.row section#mainContent article p");
			news.setContent(content.text());

//		Tags and URLs
		Elements tags = doc.select("div.row section#mainContent ul li");
		Elements tagURLs = doc.select("div.row section#mainContent ul li a");
		for(int i = 0; i < tags.size(); i++) {
			
			String absHref = tagURLs.get(i).attr("abs:href");
			news.addTags(tags.get(i).text(),absHref);
			
		}
		
//		Content images
		Elements images = doc.select("div.row section#mainContent img");
		
		for(int i = 0; i < images.size(); i++) {
			
			String absHref = images.get(i).attr("abs:src");
//			System.out.println("\t" + absHref);
			news.addPhotoURLs(absHref);
		}
		
//		All images
//		Elements images = doc.select("img").not("div.col4- bg-line bg-icon-mobile");
//		
//		for(int i = 0; i < images.size(); i++) {
//			
//			String absHref = images.get(i).attr("abs:src");
//			System.out.println("\t" + absHref);
//		}
		
		return news;
	}
	
	public void printLog(ArrayList<WebContent> webInfo) {
		
		for(int i = 0; i < webInfo.size(); i++) {
			
			log.printf("%d. %s\n", (i+1), (webInfo.get(i)).getHeadline());
			log.printf("\tURL: %s\n", (webInfo.get(i)).getURL());
			log.printf("\tContent: %s\n", (webInfo.get(i)).getContent());
			log.printf("\tDate/Time: %s \n", (webInfo.get(i)).getDate());
			log.printf("\tImage URLs: \n");
			for(String s: (webInfo.get(i)).getPhotoURLs()) {
				log.printf("%s\n", s);
			}
			log.printf("\tTags and Tag URLs: \n");
			int j = 1;
			for(String key: ((webInfo.get(i)).getTags()).keySet()){
				log.printf("%d. %s\n\t%s\n", j, key, ((webInfo.get(i)).getTags()).get(key));
				j++;
			}
			
			log.printf("\n");
			
		}
	}
}
